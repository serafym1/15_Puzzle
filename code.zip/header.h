#pragma once

#include <iostream>

#define FIELD_SIZE 4
#define TILE_PX_SIZE 50
#define GAP_PX 5
